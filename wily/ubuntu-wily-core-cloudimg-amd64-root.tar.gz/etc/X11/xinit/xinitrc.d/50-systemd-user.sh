#!/bin/sh

systemctl --user import-environment DISPLAY XAUTHORITY
